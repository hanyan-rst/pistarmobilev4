<div class="page">
  <div class="navbar">
    <div class="navbar-inner sliding">
      <div class="left">
        <a href="#" class="link back">
          <i class="icon icon-back"></i>
          <span class="ios-only">Back</span>
        </a>
      </div>
      <div class="title">Live Caller Display</div>
    </div>
  </div>
  
   <div class="page-content">
            <div class="block block-strong">
            <br />
            
            <?php
			 
			
	echo '<div id="lastHerdDetails3">'."\n";
	include '../lh_livedisplay.php';					// MMDVMDash Last Herd
	echo '</div>'."\n";
	echo "<br />\n";
	
			 
			 ?>
             </div></div>
  
</div>
